// content.js
// Inject a script into the page's context
const script = document.createElement('script');

script.textContent = `var btn_text = \`` + btn_text + `\`;\n`;
script.textContent += `var btn_url = \`` + btn_url + `\`;\n\n`;

script.textContent += `
    // This code runs in the page's context
    var coins_sent = [];

    // var CHAT_ID = "-1002118824392";
    var CHAT_ID = "1180117980";
    // var CHAT_ID = "718057913";

    // update coins_sent from local storage
    localStorage.getItem('coins_sent') ? coins_sent = JSON.parse(localStorage.getItem('coins_sent')) : coins_sent = [];

    // if local storage is empty, add coins_sent to local storage
    if (coins_sent.length == 0) {
        localStorage.setItem('coins_sent', JSON.stringify(coins_sent));
    }

    function sendToTelegram(chat_id, message_str) {
        var bot_token = '7119100296:AAFkDqrpHFHSVRHb33tur8W0apNpWGbRjzI';
        var url = 'https://api.telegram.org/bot' + bot_token + '/sendMessage';

        // Add inline keyboard markup
        var keyboard = {
            inline_keyboard: [
                [{ text: btn_text, url: btn_url }]
            ]
        };

        var data = {
            chat_id: chat_id,
            text: message_str,
            parse_mode: 'Markdown',
            link_preview_options: {
                is_disabled: true
            },
            reply_markup: JSON.stringify(keyboard) // Add inline keyboard to data
        };

        console.log('Sending message to Telegram:', data);
        
        fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data),
            })
            .then(response => response.json())
            .then(result => {
                console.log('Message sent to Telegram:', result);
            })
            .catch(error => {
                console.error('Error sending message to Telegram:', error);
            });
    }

    function capitalizeFirstLetter(string) {
        return string.charAt(0).toUpperCase() + string.slice(1);
    }
    
    function sendData() {
        var pairs = JSON.parse(document.getElementsByTagName("pre")[0].textContent).data;

        console.log('Data found on the page:', pairs);

        for (var i = 0; i < pairs.length; i++) {
            var attributes = pairs[i].attributes;

            console.log(attributes)
        
            var volume = attributes.volume;
            var buysCount = attributes.buys_count;
            var sellsCount = attributes.sells_count;
            var address = attributes.address;
            var tokenAddress = attributes.tokenAddress;

            // check if tokenAddress is in token_addresses

            // console.log(tokenAddress + ' ' + token_addresses.includes(tokenAddress));

            // if (!token_addresses.includes(tokenAddress)) {
            //     continue;
            // }

            var fdv = attributes.fdv;
            var name = attributes.name;
            var symbol = attributes.symbol;
            var createdTimestamp = attributes.created_timestamp;
            var openTimestamp = attributes.open_timestamp;
        
            // var initLiqUsd = attributes.init_liq.usd;
            // var initLiqQuote = attributes.init_liq.quote;
            // var initLiqLpAmount = attributes.init_liq.lp_amount;
            // var initLiqTimestamp = attributes.init_liq.timestamp;
            // var initLiqOpenTimestamp = attributes.init_liq.open_timestamp;
        
            // var curLiqQuote = attributes.cur_liq.quote;
            // var curLiqUsd = attributes.cur_liq.usd;
        
            var auditMintAuthority = attributes.audit.buy_tax;

            if (auditMintAuthority == false) {
                auditMintAuthority = '🟢 Disabled';
            } else if (auditMintAuthority == true) {
                auditMintAuthority = '🟡 Enabled';
            } else {
                auditMintAuthority = '🔴 Unknown';
            }

            var auditLpBurnedPerc = attributes.audit.lp_burned_perc;
            
            if(Number(auditLpBurnedPerc) >= 50){
                auditLpBurnedPerc = '🟢 ' + auditLpBurnedPerc + '%'
            } else {
                auditLpBurnedPerc = '🟡 ' + auditLpBurnedPerc + '%';
            }

            var auditTopHoldersPerc = attributes.audit.top_holders_perc;
        
            var socials = attributes.socials;

            // iterate through the keys in socials object
            for (var key in socials) {
                // if the key is not empty or null
                if (socials[key] != '' && socials[key] != null) {
                    // append the key and value to the message string
                    socials[key] = '[' + capitalizeFirstLetter(key) + '](' + socials[key] + ')';
                } else {
                    // if the key is empty or null, make the value an empty string
                    socials[key] = '';
                }

            }

            // var ticker = pairs[i].quoteTokenSymbol;
            var ticker = symbol;

            // get html content
            var html = new XMLHttpRequest();
            html.open('GET', 'https://photon-base.tinyastro.io//en/lp/' + address, false);
            html.send(null);
            var parser = new DOMParser();
            var doc = parser.parseFromString(html.responseText, 'text/html');
            // get div with data-kind="deployer" attribute
            var deployer = doc.querySelector('div[data-kind="deployer_wallet"]');
            // get address from div
            var deployerAddress = deployer.querySelector('a').getAttribute('href');

            var clog = doc.querySelector('div[data-kind="clogged_percentage"]');
            var clogValue = clog.textContent.trim();
            
            var holders = doc.querySelector('div[data-kind="holders_count"]');
            var holdersValue = holders.textContent.trim();

            var blacklist = doc.querySelector('div[data-kind="blacklist"]').textContent.trim();
            var lpLocked = doc.querySelector('div[data-kind="locked_amount"]').textContent.trim();
            var renounced = doc.querySelector('div[data-kind="renounced"]').textContent.trim();
            // var sell_limit = doc.querySelector('div[data-kind="one_sell_per_block"]').textContent.trim();
            var deployer_holdings = doc.querySelector('div[data-kind="deployer_holdings"]').textContent.trim();
            // var honeypot = doc.querySelector('div[data-kind="honeypot"]').textContent.trim();


            var message_string = '\\n🧠 [Powered by Base Alphas](https://t.me/base_alphas) \\n\\n' +
                '📘 Name: ' + name + ' \\n📌 Ticker: ' + ticker + '\\n\\n' +

                '🔹 CA:\\n\`' + tokenAddress + '\`\\n\\n' +

                '💲 Marketcap: ' + Math.round(attributes.fdv) + '\\n' +
                '💧 Liquidity: ' + Math.round(attributes.cur_liq.usd) + '\\n' +
                '🤝 Holders: ' + holdersValue + '\\n\\n' +

        
                '🌐 Volume: ' + Math.round(volume) + '\\n' +
                '🔵 Wallet Buys: ' + buysCount + '\\n' +
                '🟠 Wallet Sells: ' + sellsCount + '\\n\\n' +

                'Buy Tax: ' + attributes.audit.buy_tax + '%\\n' +
                'Sell Tax: ' + attributes.audit.sell_tax + '%\\n' +
                'Clogged: ' + clogValue + '\\n\\n' +
                
                '🔍 Audit: [Otto](https://t.me/OttoSimBot?start=' + tokenAddress + ') | ' +
                '[Tokensniffer](https://tokensniffer.com/token/base/' + tokenAddress + ')\\n' +
                '🟢 Renounced: ' + renounced + '\\n' +
                '🟢 LP Locked: ' + lpLocked + '\\n' +
                '🟢 Blacklist: ' + blacklist + '\\n' +
                'Deployer: [Basescan](' + deployerAddress + ')' + '\\n'+
                'Deployer Holdings: ' + deployer_holdings + '\\n\\n' +

                '📊 Chart:\\n' + 
                '[Dextools](https://www.dextools.io/app/en/base/pair-explorer/' + tokenAddress + ') | ' +
                '[Dexscreener](https://dexscreener.com/base/' + tokenAddress + ') | ' +
                '[Photon ⚡️](https://photon.tinyastro.io/en/r/@solalphas/' + tokenAddress + ')\\n\\n' +
        
                '💰 Quick Buy:\\n' + 
                '[Unibot](https://t.me/unibotsniper_bot?start=dylanton-' + tokenAddress + ') | ' +
                '[Shuriken](https://t.me/solana_trojanbot?start=r-dylanton-' + tokenAddress + ') | ' +
                '[Prodigy](https://t.me/ProdigySniperBot?start=PZ0E7D_snipe_' + tokenAddress + ')\\n\\n';
        


                // iterate socials with index, key and value
                if(socials != null){
                    // console.log(socials);
                    console.log(Object.entries(Object.entries(socials)))

                    for (var [index, [key, value]] of Object.entries(Object.entries(socials))) {
                        // if first index, append the socials header

                        if (index == 0) {
                            message_string += '🌎 Socials: \\n';
                        }

                        // if the value is not an empty string
                        if (value != '') {
                            // append the key and value to the message string
                            message_string += value + ' ';

                            // if not last element, append a pipe
                            if (index != Object.entries(socials).length - 1) {
                                message_string += '| ';
                            }
                        }
                    }

                    // if last element is a pipe, remove it
                    if (message_string.endsWith('| ')) {
                        message_string = message_string.slice(0, -2);
                    }
                }
                
            
            console.log('Sending message to Telegram:', message_string);

            // Placeholder for the sendToTelegram function - replace with your actual implementation
            coins_sent = JSON.parse(localStorage.getItem('coins_sent'));
            if (coins_sent.indexOf(name) == -1) {
                coins_sent.push(name);
                localStorage.setItem('coins_sent', JSON.stringify(coins_sent));
                // setTimeout(function(){sendToTelegram(CHAT_ID, message_string);}, i*1000);
                sendToTelegram(CHAT_ID, message_string);
            }
        }        
    }

    // Create a MutationObserver instance
    const observer = new MutationObserver((mutationsList, observer) => {
        // Handle mutations
        // for (const mutation of mutationsList) {
        //     if (mutation.type === 'attributes' || mutation.type === 'childList') {
        //         // The observed element or its children have changed
        //         console.log('DOM change detected:', mutation);
        //         // Perform actions in response to the change
        //     }
        // }
        console.log('DOM change detected:', mutationsList);
        sendData();
    });

    // Options for the observer (specify what changes to observe)
    const observerOptions = {
        attributes: true,            // Watch for changes to attributes
        childList: true,             // Watch for changes to the child nodes
        subtree: true,               // Watch for changes in the entire subtree
        attributeOldValue: false,     // Record the old value of attributes
        attributeFilter: ['class'],  // Specify the attributes to observe (if attributes: true)
    };

    // Add a listener to receive messages from the content script
    window.addEventListener('message', (event) => {
        // Ensure the message is from a trusted source (if needed)
        // if (event.source !== window) return;

        // Handle the received message
        console.log('Page received message:', event.data);

        // You can also send a response back to the content script if needed
        // event.source.postMessage('Response from page', '*');

        setTimeout(() => {
            // Check if the data is available on the page
            sendData();
            // try {
            //     sendData();
            //     const targetNode = document.body;
            //     // Start observing the target node for configured mutations
            //     // observer.observe(targetNode, observerOptions);
            // } catch (e) {
            //     console.error('Data not found on the page');
            //     console.error(e);
            // }

            // refresh the page every 1 minute
            setTimeout(() => {
                window.location.reload();
            }, 60000);
            
        }, 3000);
        

    });
    `;

// Inject the script into the page
(document.head || document.documentElement).appendChild(script);
script.parentNode.removeChild(script);

// Communicate with the injected script
window.postMessage('Hello from content script!', '*');
