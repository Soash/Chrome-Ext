// content.js
// Inject a script into the page's context
const script = document.createElement('script');

script.textContent = `var btn_text = \`` + btn_text + `\`;\n`;
script.textContent += `var btn_url = \`` + btn_url + `\`;\n\n`;

script.textContent += `
    // This code runs in the page's context
    var coins_sent = [];

    var CHAT_ID = "1180117980";

    // update coins_sent from local storage
    localStorage.getItem('coins_sent') ? coins_sent = JSON.parse(localStorage.getItem('coins_sent')) : coins_sent = [];

    // if local storage is empty, add coins_sent to local storage
    if (coins_sent.length == 0) {
        localStorage.setItem('coins_sent', JSON.stringify(coins_sent));
    }

    function sendToTelegram(chat_id, message_str) {
        var bot_token = '7004480011:AAEWJOQquC00L5SbPORl7OrvGcMoEbzS6w4';
        var url = 'https://api.telegram.org/bot' + bot_token + '/sendMessage';

        // Add inline keyboard markup
        var keyboard = {
            inline_keyboard: [
                [{ text: btn_text, url: btn_url }]
            ]
        };

        var data = {
            chat_id: chat_id,
            text: message_str,
            parse_mode: 'Markdown',
            link_preview_options: {
                is_disabled: true
            },
            reply_markup: JSON.stringify(keyboard) // Add inline keyboard to data
        };

        console.log('Sending message to Telegram:', data);
        
        fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data),
            })
            .then(response => response.json())
            .then(result => {
                console.log('Message sent to Telegram:', result);
            })
            .catch(error => {
                console.error('Error sending message to Telegram:', error);
            });
    }

    function capitalizeFirstLetter(string) {
        return string.charAt(0).toUpperCase() + string.slice(1);
    }
    
    function sendData() {

        console.log('ok');

        var selector = '.flex.flex-col.gap-y-3.p-0.md\\\\:p-3.h-full.md\\\\:h-auto';

        var elements = document.querySelectorAll(selector);

        var graduatedElement = elements[2];

        console.log(graduatedElement);

        const pumpCards = graduatedElement.querySelectorAll('.pump-card');

        const pumpCardCount = pumpCards.length;
        console.log(pumpCardCount); 

       
        for (let i = 0; i < pumpCards.length; i++) {

            console.log(pumpCards[i]);

            var nameElement = pumpCards[i].querySelector('.font-medium.text-grey-50.whitespace-nowrap.min-w-max.overflow-ellipsis.line-clamp-1.text-sm.\\\\!leading-\\\\[14px\\\\]');
            var name = nameElement.textContent;
            console.log(name);

            var tickerElement = pumpCards[i].querySelector('.font-normal.text-grey-200.overflow-ellipsis.line-clamp-1.text-xs.\\\\!leading-\\\\[12px\\\\]');
            var ticker = tickerElement.textContent;
            console.log(ticker);
        
            var linkElement = pumpCards[i].querySelector('a.w-full.h-full.absolute.inset-0.z-\\\\[1\\\\]');
            // console.log(linkElement);
            var hrefValue = linkElement.getAttribute('href');
            const url = new URL(hrefValue, window.location.origin);
            const tokenAddress = url.searchParams.get('address');
            console.log(tokenAddress);

            var tokenAgeElement = pumpCards[i].querySelector('.\\\\!text-xs.\\\\!leading-none.inline-flex.text-grey-200.font-medium');
            var tokenAge = tokenAgeElement.textContent;
            console.log(tokenAge);

            var marketCapElement = pumpCards[i].querySelector('.flex.items-center.gap-x-1.pl-1 span:nth-child(2)');
            var marketCap = marketCapElement.textContent;
            console.log(marketCap);

            var volumeElement = pumpCards[i].querySelector('.flex.items-center.justify-between.mt-2.z-10 div:nth-child(2)');
            var query = ".flex.items-center.justify-between.mt-2.z-10 div:nth-child(2) div:nth-child(" + (volumeElement.children.length-1) + ") span:nth-child(2)";
            var volume = pumpCards[i].querySelector(query).textContent;
            console.log(volume);

            var holdersElement = pumpCards[i].querySelector('.flex.items-center.justify-between.mt-2.z-10 div:nth-child(2) div:nth-child(1) span:nth-child(2)');
            var holders = holdersElement.textContent;
            console.log(holders);

            try{
                var top10Element = pumpCards[i].querySelector('.flex.items-center.gap-x-1.border-r.border-grey-500.px-1.text-xs.leading-none.text-green-700 span:nth-child(2)');
                var top10 = top10Element.textContent;
                console.log(top10);
            } catch (error) {
                var top10Element = pumpCards[i].querySelector('.flex.items-center.gap-x-1.border-r.border-grey-500.px-1.text-xs.leading-none.text-red-700 span:nth-child(2)');
                var top10 = top10Element.textContent;
                console.log(top10);
            }
           
            var devHoldingsElement = pumpCards[i].querySelector('.flex.items-center.z-10 div:nth-child(3) span:nth-child(2)');
            var dh = devHoldingsElement.textContent;
            console.log(dh);
        
            var insiderElement = pumpCards[i].querySelector('.text-xs.leading-\\\\[1\\\\].font-normal.ml-0\\\\.5');
            var insider = insiderElement ? insiderElement.textContent : 'N/A';
            console.log('Insider:', insider);

            var href = pumpCards[i].querySelector('a.w-full.h-full.absolute.inset-0.z-\\\\[1\\\\]').getAttribute('href');
            console.log(href);

            var socialElements = pumpCards[i].querySelector('.flex.gap-x-\\\\[6px\\\\]');
            console.log(socialElements);
            var links = socialElements.querySelectorAll('a');
            var linksCount = links.length;
            console.log(linksCount);

            var social = "";
            var x = 1;
            links.forEach(function(link) {
                console.log(link.href);

                if (link.href.includes('pump.fun')){
                    social = social + '[Pump](' + link.href + ')';
                } else if (link.href.includes('x.com')){
                    social = social + '[X](' + link.href + ')';
                } else if (link.href.includes('t.me')){
                    social = social + '[Telegram](' + link.href + ')';
                } else{
                    social = social + '[Website](' + link.href + ')';
                }
                
                if (x < linksCount){
                    social = social + ' | ';
                    x += 1;
                }
                
            });
            console.log(social);
            

            var message_string = '\\n🧠 [Powered by Blockchain Alphas](https://t.me/blockchain_alphas) \\n\\n' +
            '📘 Name: ' + name + ' \\n'+
            '📌 Ticker: ' + ticker + '\\n\\n' +

            '🔹 Quick Buy: [Trojan](https://t.me/solana_trojanbot?start=r-dylanton-' + tokenAddress + ')\\n\\n' + 

            '🕰 Token Age: ' + tokenAge + '\\n' +
            '💲 Market Cap: ' + marketCap + '\\n' +
            '🌐 Volume: ' + volume + '\\n' +
            '🤝 Holders: ' + holders + '\\n\\n' +

            '📊 Chart  (https://bullx.io' + href + ')\\n\\n' +

            '🔍 Audit \\n' +
            '🔴 Top 10: ' + top10 + '\\n' +
            '🟢 Dev Holdings: ' + dh + '\\n' +
            '🔴 Insider: ' + insider + '\\n\\n' +
            
            '🌎 Socials: \\n' + social;
                
            console.log('Sending message to Telegram:', message_string);

            // Placeholder for the sendToTelegram function - replace with your actual implementation
            coins_sent = JSON.parse(localStorage.getItem('coins_sent'));
            if (coins_sent.indexOf(name) == -1) {
                coins_sent.push(name);
                localStorage.setItem('coins_sent', JSON.stringify(coins_sent));
                // setTimeout(function(){sendToTelegram(CHAT_ID, message_string);}, i*1000);
                sendToTelegram(CHAT_ID, message_string);
            }
        }        
    }

    // Create a MutationObserver instance
    const observer = new MutationObserver((mutationsList, observer) => {
        console.log('DOM change detected:', mutationsList);
        sendData();
    });

    // Options for the observer (specify what changes to observe)
    const observerOptions = {
        attributes: true,            // Watch for changes to attributes
        childList: true,             // Watch for changes to the child nodes
        subtree: true,               // Watch for changes in the entire subtree
        attributeOldValue: false,     // Record the old value of attributes
        attributeFilter: ['class'],  // Specify the attributes to observe (if attributes: true)
    };

    // Add a listener to receive messages from the content script
    window.addEventListener('message', (event) => {

        console.log('Page received message:', event.data);

        setTimeout(() => {

            try {
                sendData();

                setTimeout(() => {
                    window.location.reload();
                }, 60000);
            }
            catch(err) {
                console.log(err);
            }
            
    
        }, 10000); 

    });


    `;

// Inject the script into the page
(document.head || document.documentElement).appendChild(script);
script.parentNode.removeChild(script);

// Communicate with the injected script
window.postMessage('Hello from content script!', '*');
