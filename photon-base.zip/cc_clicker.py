import pyautogui
import time
from pyautogui import ImageNotFoundException
import random

# box image to look for
box = 'box.png'

while True:
    # wait for a few seconds before the next check
    time.sleep(10)
    
    # locate the box image on the screen
    try:
        box_location = pyautogui.locateOnScreen(box)
    except ImageNotFoundException:
        print('Image not found!')
        continue

    # if the box is found, perform actions
    if box_location:
        box_x, box_y = pyautogui.center(box_location)

        # introduce a random delay before moving the cursor to the box
        time.sleep(random.uniform(0.5, 2.0))

        # move the mouse to the center of the box with varying speed
        pyautogui.moveTo(box_x, box_y, duration=random.uniform(0.5, 1.5))

        # introduce a random delay before clicking
        time.sleep(random.uniform(0.2, 0.5))

        # click the box
        pyautogui.click()
        print('Box clicked!')

        # introduce a delay before moving the box to a new location
        time.sleep(random.uniform(1.0, 3.0))

        # move the box to a new location with varying speed
        pyautogui.moveTo(100, 100, duration=random.uniform(0.5, 1.5))

        # add zigzag movement
        for _ in range(5):
            pyautogui.move(20, 0, duration=random.uniform(0.2, 0.5))
            pyautogui.move(-20, 0, duration=random.uniform(0.2, 0.5))

    else:
        print('Box not found!')
