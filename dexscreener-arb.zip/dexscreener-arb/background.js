// background.js or popup.js

// Add a listener to receive messages from the content script
window.addEventListener('message', (event) => {
    // Ensure the message is from a trusted source (if needed)
    // if (event.source !== window) return;
  
    // Handle the received message
    console.log('Content script received message:', event.data);
  
    // You can also send a response back to the content script if needed
    // event.source.postMessage('Response from background script', '*');
  });
  