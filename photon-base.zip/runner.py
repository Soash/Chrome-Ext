import webbrowser
import os
import time

CHAT_DATA_FILE = 'link_data.txt'

def open_chrome():
    with open(CHAT_DATA_FILE, 'r') as file:
        url = file.readline().strip()
        if url:
            webbrowser.open(url)

def close_chrome():
    os.system("pkill chrome")

def job():
    close_chrome()
    time.sleep(2)  # Give some time for the browser to close
    open_chrome()

if __name__ == "__main__":
    while True:
        job()
        time.sleep(3600)