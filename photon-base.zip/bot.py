#!/usr/bin/env python3

import time
import os

import telepot
from telepot.loop import MessageLoop

# Replace 'YOUR_BOT_TOKEN' with your actual bot token
TOKEN = '6607154184:AAHGn8tIu6uhVT6lkvx-Lat53M7wRFYIV6c'
CHAT_DATA_FILE = 'link_data.txt'

def handle_link(msg):
    content_type, chat_type, chat_id = telepot.glance(msg)

    # if private message
    if chat_type == 'private':
        if 'text' in msg:
            text = msg['text']

            if text == '/start':
                bot.sendMessage(chat_id, 'Hi! Please use /link command with a URL to save the link.')
                return
            elif text.startswith('/help'):
                bot.sendMessage(chat_id, '''Commands:
/start - Start the bot
/help - Show help
/link <URL> - Save the link which will be opened by browser to get data
/edit_ad_btn <Button_Text> | <Button_URL> - Edit and add button`)''')
                return
            elif text.startswith('/link '):
                new_link = text.split('/link ')[1]

                # get previous link
                if os.path.exists(CHAT_DATA_FILE):
                    with open(CHAT_DATA_FILE, 'r') as file:
                        old_link = file.read()
                else:
                    old_link = None

                with open(CHAT_DATA_FILE, 'w') as file:
                    file.write(new_link)
                    
                bot.sendMessage(chat_id, f'Link saved!\nNew Link: {new_link}\nPrevious Link: {old_link}')
                # restart vnc server
                os.system("sudo systemctl restart vncserver@1.service")
                return
            elif text.startswith('/edit_ad_btn'):
                # check if it has two arguments
                text = text.replace("/edit_ad_btn", "").strip()
                if len(text.split('|')) == 2:
                    btn_text, btn_link = text.split('|')
                    btn_text = btn_text.strip()
                    btn_link = btn_link.strip()
                    with open("btn_data.js", 'w') as file:
                        file.write(f'var btn_text = "{btn_text}";\nvar btn_url = "{btn_link}";')
                    bot.sendMessage(chat_id, f'Button text and link saved: {btn_text} | {btn_link}')
                    # restart vnc server
                    os.system("sudo systemctl restart vncserver@1.service")
                    return
                else:
                    bot.sendMessage(chat_id, 'Invalid command. Please use /edit_ad_btn command with a URL.')
            elif text.startswith("/restart_vnc"):
                os.system("sudo systemctl restart vncserver@1.service")
                bot.sendMessage(chat_id, 'VNC server restarted.')
            else:
                bot.sendMessage(chat_id, 'Invalid command. Please use /link command with a URL.')
        
# Replace 'YOUR_BOT_TOKEN' with your actual bot token
bot = telepot.Bot(TOKEN)
MessageLoop(bot, handle_link).run_as_thread()

# keep the program running
while True:
    time.sleep(10)

