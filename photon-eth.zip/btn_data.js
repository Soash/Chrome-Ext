var btn_text = "For ad space dm @dylanton";
var btn_url = "https://t.me/dylanton";