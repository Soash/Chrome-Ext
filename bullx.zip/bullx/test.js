
var selector = '.flex.flex-col.gap-y-3.p-0.md\\:p-3.h-full.md\\:h-auto';
var elements = document.querySelectorAll(selector);
var graduatedElement = elements[2];
console.log(graduatedElement);
const pumpCards = graduatedElement.querySelectorAll('.pump-card');
const pumpCardCount = pumpCards.length;
console.log(pumpCardCount);

x = pumpCards[2];

var test = x.querySelector('.flex.items-center.justify-between.mt-2.z-10 div:nth-child(2)');
var query = ".flex.items-center.justify-between.mt-2.z-10 div:nth-child(2) div:nth-child(" + (test.children.length-1) + ") span:nth-child(2)";
var test2 = test.querySelector(query).textContent;
console.log(test2);
