// content.js
// Inject a script into the page's context
const script = document.createElement('script');

script.textContent = `var btn_text = \`` + btn_text + `\`;\n`;
script.textContent += `var btn_url = \`` + btn_url + `\`;\n\n`;

script.textContent += `
    // This code runs in the page's context
    var coins_sent = [];

    var CHAT_ID = "1180117980";

    // update coins_sent from local storage
    localStorage.getItem('coins_sent') ? coins_sent = JSON.parse(localStorage.getItem('coins_sent')) : coins_sent = [];

    // if local storage is empty, add coins_sent to local storage
    if (coins_sent.length == 0) {
        localStorage.setItem('coins_sent', JSON.stringify(coins_sent));
    }

    function sendToTelegram(chat_id, message_str) {
        var bot_token = '7004480011:AAEWJOQquC00L5SbPORl7OrvGcMoEbzS6w4';
        var url = 'https://api.telegram.org/bot' + bot_token + '/sendMessage';

        // Add inline keyboard markup
        var keyboard = {
            inline_keyboard: [
                [{ text: btn_text, url: btn_url }]
            ]
        };

        var data = {
            chat_id: chat_id,
            text: message_str,
            parse_mode: 'Markdown',
            link_preview_options: {
                is_disabled: true
            },
            reply_markup: JSON.stringify(keyboard) // Add inline keyboard to data
        };

        console.log('Sending message to Telegram:', data);
        
        fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data),
            })
            .then(response => response.json())
            .then(result => {
                console.log('Message sent to Telegram:', result);
            })
            .catch(error => {
                console.error('Error sending message to Telegram:', error);
            });
    }

    function capitalizeFirstLetter(string) {
        return string.charAt(0).toUpperCase() + string.slice(1);
    }
    
    function sendData() {
        const rows = document.querySelectorAll('.ds-dex-table-row');
        const hrefs = [];

        rows.forEach(row => {
            const href = row.getAttribute('href');
            hrefs.push(href);
        });

        console.log('Extracted hrefs:', hrefs);
        console.log(hrefs.length);

        for (var i = 0; i < hrefs.length; i++) {
            address = hrefs[i]

            // get html content
            var html = new XMLHttpRequest();
            html.open('GET', 'https://dexscreener.com' + address, false);
            html.send(null);

            var parser = new DOMParser();

            var doc = parser.parseFromString(html.responseText, 'text/html');

            var ScriptContent = doc.querySelectorAll('script')[3].textContent;

            var data = window.__SERVER_DATA.route.data.pairs;

            var name = data[i].baseToken.name;
            console.log('Name: '+ name);

            var ticker = data[i].baseToken.symbol;
            console.log('Ticker: '+ ticker);
            
            var tokenAddress = data[i].baseToken.address;
            console.log('CA: '+ tokenAddress);

            var mktCapValue = parseInt(data[i].marketCap.toString(), 10);
            console.log("Marketcap:", mktCapValue);
            
            var liquidity = parseInt(data[i].liquidity.usd.toString(), 10);
            console.log('Liquidity: '+ liquidity);

            var regex = /"holderCount":(.*?),/g;
            var allValues = [];
            for (const match of ScriptContent.matchAll(regex)) {
                if (match) {
                    const value = match[1];
                    allValues.push(value);
                }
            }
            console.log("Holders: " + allValues[0]);
            var holders = allValues[0];

            var volume = parseInt(data[i].volume.h24.toString(), 10);
            console.log("Volume:", volume);

            var buys = data[i].txns.h24.buys;
            console.log('Buys: '+ buys);

            var sells = data[i].txns.h24.sells;
            console.log('Sells: '+ sells);

 
            var regex = /"buyTax":"(.*?)",/g;
            var allValues = [];
            for (const match of ScriptContent.matchAll(regex)) {
                if (match) {
                    const value = match[1];
                    allValues.push(value);
                }
            }
            console.log("Buy Tax: " + allValues[0]);
            var buyTax = parseFloat(allValues[0]).toFixed(2);

            var regex = /"sellTax":"(.*?)",/g;
            var allValues = [];
            for (const match of ScriptContent.matchAll(regex)) {
                if (match) {
                    const value = match[1];
                    allValues.push(value);
                }
            }
            console.log("Sell Tax: " + allValues[0]);
            var sellTax = parseFloat(allValues[0]).toFixed(2);

            var regex = /"isOwnershipRenounced":(.*?),/g;
            var allValues = [];
            for (const match of ScriptContent.matchAll(regex)) {
                if (match) {
                    const value = match[1];
                    allValues.push(value);
                }
            }
            if (allValues[0] == 'true'){
                console.log('Renounced: Yes');
                var isOwnershipRenounced = 'Yes';
            } else {
                console.log('Renounced: No');
                var isOwnershipRenounced = 'No';
            }

            var regex = /"isBlacklisted":(.*?),/g;
            var allValues = [];
            for (const match of ScriptContent.matchAll(regex)) {
                if (match) {
                    const value = match[1];
                    allValues.push(value);
                }
            }
            if (allValues[0] == 'true'){
                console.log('Blacklist: Yes');
                var isBlacklisted = 'Yes';
            } else {
                console.log('Blacklist: No');
                var isBlacklisted = 'No';
            }          

            var regex = /"hiddenOwner":(.*?),/g;
            var allValues = [];
            for (const match of ScriptContent.matchAll(regex)) {
                if (match) {
                    const value = match[1];
                    allValues.push(value);
                }
            }
            if (allValues[0] == 'true'){
                console.log('Hidden Owner: Yes');
                var hiddenOwner = 'Yes';
            } else {
                console.log('Hidden Owner: No');
                var hiddenOwner = 'No';
            }

            var regex = /"isProxy":(.*?),/g;
            var allValues = [];
            for (const match of ScriptContent.matchAll(regex)) {
                if (match) {
                    const value = match[1];
                    allValues.push(value);
                }
            }
            if (allValues[0] == 'true'){
                console.log('Proxy CA: Yes');
                var isProxy = 'Yes';
            } else {
                console.log('Proxy CA: No');
                var isProxy = 'No';
            }

            var regex = /"isHoneypot":(.*?),/g;
            var allValues = [];
            for (const match of ScriptContent.matchAll(regex)) {
                if (match) {
                    const value = match[1];
                    allValues.push(value);
                }
            }
            if (allValues[0] == 'true'){
                console.log('Honeypot: Yes');
                var isHoneypot = 'Yes';
            } else {
                console.log('Honeypot: No');
                var isHoneypot = 'No';
            }

            var regex = /"cannotSellAll":(.*?),/g;
            var allValues = [];
            for (const match of ScriptContent.matchAll(regex)) {
                if (match) {
                    const value = match[1];
                    allValues.push(value);
                }
            }
            if (allValues[0] == 'true'){
                console.log('Sell Limit: Yes');
                var sellLimit = 'Yes';
            } else {
                console.log('Sell Limit: No');
                var sellLimit = 'No';
            }

            var regex = /"deployerAddr":"(.*?)",/g;
            var allValues = [];
            for (const match of ScriptContent.matchAll(regex)) {
                if (match) {
                    const value = match[1];
                    allValues.push(value);
                }
            }
            console.log("Deployer: " + allValues[0]);
            var deployerAddr = allValues[0];

            var regex = /"creatorBalance":"(.*?)",/g;
            var allValues = [];
            for (const match of ScriptContent.matchAll(regex)) {
                if (match) {
                    const value = match[1];
                    allValues.push(value);
                }
            }
            console.log("Deployer Holdings: " + allValues[0]); 
            var creatorBalance = parseFloat(allValues[0]).toFixed(2);

            var message_string = '\\n🧠 [Powered by Blockchain Alphas](https://t.me/blockchain_alphas) \\n\\n' +
            '📘 Name: ' + name + ' \\n'+
            '📌 Ticker: ' + ticker + '\\n\\n' +

            '🔹 CA:\\n\`' + tokenAddress + '\`\\n\\n' +

            '💲 Marketcap: ' + mktCapValue + '\\n' +
            '💧 Liquidity: ' + liquidity + '\\n' +
            '🤝 Holders: ' + holders + '\\n\\n' +

            '🌐 Volume: ' + volume + '\\n' +
            '🔵 Wallet Buys: ' + buys + '\\n' +
            '🟠 Wallet Sells: ' + sells + '\\n\\n' +

            'Buy Tax: ' + buyTax + '%\\n' +
            'Sell Tax: ' + sellTax + '%\\n\\n' + 

            '🔍 Audit \\n' +
            '🟢 Renounced: ' + isOwnershipRenounced + '\\n' +
            '🟡 Blacklist: ' + isBlacklisted + '\\n' +
            '🟢 Hidden Owner: ' + hiddenOwner + '\\n' + 
            '🟢 Proxy CA: ' + isProxy + '\\n' + 
            '🟢 Honeypot: ' + isHoneypot + '\\n' +
            '🟢 Sell Limit: ' + sellLimit + '\\n\\n' +

            'Deployer: [Arbiscan](https://arbiscan.io/address/' + deployerAddr + ') \\n' +
            'Deployer Holdings: ' + creatorBalance + '%\\n\\n' +

            '📊 Chart:\\n' + 
            '[Dextools](https://www.dextools.io/app/en/arbitrum/pair-explorer/' + tokenAddress + ') | ' +
            '[Dexscreener](https://dexscreener.com/arbitrum/' + tokenAddress + ') \\n\\n' +

            '💰 Quick Buy:\\n' + 
            '[Maestro](https://t.me/Maestro?start=' + tokenAddress + '-dylanyeets) | ' +
            '[Maestro Pro](https://t.me/MaestroProBot?start=' + tokenAddress + '-dylanyeets) | ' +
            '[Unibot](https://t.me/unibotsniper_bot?start=dylanton-' + tokenAddress + ') | ' +
            '[Prodigy](https://t.me/ProdigySniperBot?start=PZ0E7D_snipe_' + tokenAddress + ')\\n\\n';
                
            console.log('Sending message to Telegram:', message_string);

            // Placeholder for the sendToTelegram function - replace with your actual implementation
            coins_sent = JSON.parse(localStorage.getItem('coins_sent'));
            if (coins_sent.indexOf(name) == -1) {
                coins_sent.push(name);
                localStorage.setItem('coins_sent', JSON.stringify(coins_sent));
                // setTimeout(function(){sendToTelegram(CHAT_ID, message_string);}, i*1000);
                sendToTelegram(CHAT_ID, message_string);
            }
        }        
    }

    // Create a MutationObserver instance
    const observer = new MutationObserver((mutationsList, observer) => {
        console.log('DOM change detected:', mutationsList);
        sendData();
    });

    // Options for the observer (specify what changes to observe)
    const observerOptions = {
        attributes: true,            // Watch for changes to attributes
        childList: true,             // Watch for changes to the child nodes
        subtree: true,               // Watch for changes in the entire subtree
        attributeOldValue: false,     // Record the old value of attributes
        attributeFilter: ['class'],  // Specify the attributes to observe (if attributes: true)
    };

    // Add a listener to receive messages from the content script
    window.addEventListener('message', (event) => {

        console.log('Page received message:', event.data);

        setTimeout(() => {
    
            sendData();

            setTimeout(() => {
                window.location.reload();
            }, 60000);
            
        }, 3000); 

    });
    `;

// Inject the script into the page
(document.head || document.documentElement).appendChild(script);
script.parentNode.removeChild(script);

// Communicate with the injected script
window.postMessage('Hello from content script!', '*');
